# RoboAnimator---Blender-Addon
Helps animating wheeled robots in Blender and export data for engineering requirements. 



Covers multiple phase of the research.

true_roboanimator/
  __init__.py
  operators.py
  selection.py         # selection / organization / calibration
  feasibility.py       # path feasibility
  rpm.py               # wheel RPM + cache
  ui.py                # panel only