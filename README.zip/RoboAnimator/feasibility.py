import bpy
from math import pi, sin, cos

# ---------- properties (separate from selection) ----------

_AXIS_ITEMS = [
    ('PX', '+X', ''), ('NX', '-X', ''),
    ('PY', '+Y', ''), ('NY', '-Y', ''),
    ('PZ', '+Z', ''), ('NZ', '-Z', ''),
]

class FeasProps(bpy.types.PropertyGroup):
    body_fwd: bpy.props.EnumProperty(
        name="Body Forward Axis",
        items=_AXIS_ITEMS,
        default='PY',
    )
    side_tol_ms: bpy.props.FloatProperty(  # m/s like V8
        name="Sideways tolerance (m/s)",
        description="Max allowed lateral speed",
        default=0.02, min=0.0, precision=6
    )
    path_type: bpy.props.EnumProperty(
        name="Autocorrect Path Type",
        items=[('S', 'S-Curve', ''), ('BEZ', 'Bezier', '')],
        default='S'
    )
    tan_scale: bpy.props.FloatProperty(
        name="Tangent scale (S-Ease)",
        description="Scale for S-curve tangents",
        default=1.0, min=0.0, precision=3
    )
    rot_frac: bpy.props.FloatProperty(
        name="Rotation fraction (Linear)",
        description="Fraction of segment used for in-place rotation in linear mode",
        default=0.25, min=0.0, max=1.0, precision=3
    )

def register_feas_props():
    bpy.types.Scene.ra_feas = bpy.props.PointerProperty(type=FeasProps)

def unregister_feas_props():
    if hasattr(bpy.types.Scene, "ra_feas"):
        del bpy.types.Scene.ra_feas

# ---------- helpers ----------

def _yaw_to_heading(axis_id, yaw_world):
    # Map world yaw (about Z) to robot-forward heading in XY.
    if axis_id == 'PX': return yaw_world
    if axis_id == 'NX': return yaw_world + pi
    if axis_id == 'PY': return yaw_world + pi/2.0
    if axis_id == 'NY': return yaw_world - pi/2.0
    # Z-forward not meaningful for planar heading; use +Y mapping
    return yaw_world + pi/2.0

def _sample_pose(ctx, frame):
    scn = ctx.scene
    scn.frame_set(frame)
    ch = scn.ra_props.chassis
    mw = ch.matrix_world
    loc = mw.translation
    yaw = mw.to_euler('XYZ').z
    return float(loc.x), float(loc.y), float(loc.z), float(yaw)

# ---------- public API ----------

def analyze(ctx):
    scn = ctx.scene
    P  = scn.ra_props
    F  = scn.ra_feas
    ch = P.chassis
    if not ch:
        return {"ok": False, "msg": "Assign the chassis."}
    if scn.frame_end <= scn.frame_start:
        return {"ok": False, "msg": "Scene frame range invalid."}

    fps = scn.render.fps / scn.render.fps_base
    dt  = 1.0 / float(fps)
    f0, f1 = scn.frame_start, scn.frame_end

    # first sample
    x0, y0, _z0, yaw0 = _sample_pose(ctx, f0)
    h0 = _yaw_to_heading(F.body_fwd, yaw0)

    max_side_ms = 0.0
    viol_frames = []

    for f in range(f0 + 1, f1 + 1):
        x1, y1, _z1, yaw1 = _sample_pose(ctx, f)
        h1 = _yaw_to_heading(F.body_fwd, yaw1)

        # mid-step heading
        h_mid = 0.5 * (h0 + h1)

        # lateral unit at mid-step
        latx, laty = -sin(h_mid), cos(h_mid)

        dx, dy = (x1 - x0), (y1 - y0)
        side_m = dx * latx + dy * laty
        side_ms = abs(side_m) / dt  # m/s

        if side_ms > max_side_ms:
            max_side_ms = side_ms
        if side_ms > F.side_tol_ms:
            viol_frames.append(f)

        # advance
        x0, y0, h0 = x1, y1, h1

    ok = (len(viol_frames) == 0)
    msg = "Max sideways {:.6f} m/s  Tol {:.6f} m/s  Violations {}".format(
        max_side_ms, F.side_tol_ms, len(viol_frames)
    )
    return {
        "ok": ok,
        "msg": msg,
        "violations": len(viol_frames),
        "violation_frames": viol_frames,
        "side_tol": F.side_tol_ms,
    }

def autocorrect(ctx):
    ns = bpy.app.driver_namespace
    ns["TRA_AUTO"] = {
        "mode": ctx.scene.ra_feas.path_type,   # 'S' or 'BEZ'
        "tan_scale": ctx.scene.ra_feas.tan_scale,
        "rot_frac": ctx.scene.ra_feas.rot_frac,
    }
    return {"ok": True, "msg": "Autocorrect planned: {}".format(ns['TRA_AUTO']['mode'])}

def revert_autocorrect(ctx):
    ns = bpy.app.driver_namespace
    if "TRA_AUTO" in ns:
        ns.pop("TRA_AUTO", None)
        return {"ok": True, "msg": "Autocorrect plan cleared."}
    return {"ok": True, "msg": "Nothing to revert."}

# Back-compat for ValidatePath
def check(ctx):
    return analyze(ctx)
