# RoboAnimator---Blender-Addon
Helps animating wheeled robots in Blender and export data for engineering requirements. 



Covers multiple phase of the research.
